﻿namespace ConsoleAppSignInADB2C.Models;

public class TokenB2C
{
    public string? IdToken { get; set; }
    public string? Header { get; set; }
    public string? Payload { get; set; }
    public string? Signature { get; set; }
}